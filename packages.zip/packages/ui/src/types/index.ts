﻿export type NtThemeName = 'dark' | 'light' | 'high-contrast';

export type NtDensityName = 'compact' | 'comfortable' | 'spacious';

export type NtAccentName =
  | 'orange'
  | 'blue'
  | 'green'
  | 'purple'
  | 'neutral';

export type NtComponentSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

export type NtComponentState =
  | 'default'
  | 'hover'
  | 'active'
  | 'focus'
  | 'disabled'
  | 'loading'
  | 'success'
  | 'warning'
  | 'danger'
  | 'info';
