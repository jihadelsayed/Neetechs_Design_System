﻿import { cp, mkdir } from 'node:fs/promises';

await mkdir('dist', { recursive: true });

await cp('src/styles', 'dist/styles', { recursive: true });
await cp('src/components', 'dist/components', { recursive: true });
await cp('src/patterns', 'dist/patterns', { recursive: true });
await cp('src/ai', 'dist/ai', { recursive: true });
await cp('src/domain', 'dist/domain', { recursive: true });
await cp('docs', 'dist/docs', { recursive: true });
