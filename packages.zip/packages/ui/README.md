﻿# @neetechs/ui

Official framework-agnostic Neetechs UI design system.

This package contains:

- CSS design tokens
- Themes
- Base styles
- Component CSS classes
- Utility CSS
- Pure TypeScript behavior helpers

It is intentionally not tied to Angular, React, Next.js, or any other framework.

Framework wrappers should live in separate packages later:

- @neetechs/ui-angular
- @neetechs/ui-react
